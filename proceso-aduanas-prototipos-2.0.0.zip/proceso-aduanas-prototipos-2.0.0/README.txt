========================================================================
SISTEMA INTEGRADO DE CONTROL FRONTERIZO - GRUPO 8
PROTOTIPO FINAL DE ALTA FIDELIDAD - VERSÍON 2.0.0 (Entrega Final)
========================================================================

Descripción:
Versión definitiva del prototipo del proyecto. Integra tanto el flujo de autoatención
del Turista (con generación de QR) como el Portal Interno para Funcionarios de Barrera.

Componentes Incluidos:
- portal_turista_final.html: Flujo completo optimizado para turistas.
- portal_funcionario_final.html: Interfaz táctil para el funcionario en garita que 
  escanea el QR y visualiza el semáforo de interoperabilidad (PDI, SAG, Aduanas).

Hitos cubiertos según el DAS:
- Cumple con las 10 Heurísticas de Nielsen (Validación visual inmediata).
- Simula la apertura automática de la barrera ("Barrera Levantada").
