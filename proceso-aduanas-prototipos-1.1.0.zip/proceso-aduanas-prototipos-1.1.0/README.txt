========================================================================
SISTEMA INTEGRADO DE CONTROL FRONTERIZO - GRUPO 8
PROTOTIPO DE BAJA FIDELIDAD - VERSÍON 1.1.0 (Segunda Revisión)
========================================================================

Descripción:
Evolución del prototipo de pasajeros. Se incorpora el flujo completo de carga 
documental con controles de peso/formato y el cuestionario interactivo del SAG.

Componentes Incluidos:
- portal_turista_v1.1.html: Incorpora Paso 2 (Gestión Documental), Paso 3 (Pasajeros) 
  y Paso 4 (Declaración Jurada SAG con Código QR final).

Novedades Técnicas en esta versión:
- Validación simulada de archivos límite 5MB (PDF/JPG).
- Cuestionario dinámico SAG con lógica Sí/No.
- Generación del Código QR de comprobante.
