========================================================================
SISTEMA INTEGRADO DE CONTROL FRONTERIZO - GRUPO 8
PROTOTIPO DE BAJA FIDELIDAD - VERSÍON 1.0.0 (Primera Revisión)
========================================================================

Descripción:
Versión inicial del prototipo enfocado exclusivamente en el núcleo del Portal de 
Tránsito Fronterizo para Pasajeros. Contiene la interfaz de inicio y la captura 
básica de datos del vehículo.

Componentes Incluidos:
- portal_turista_v1.html: Pantalla de Inicio (Clave Única) y Paso 1 (Datos del Vehículo).

Objetivo de la revisión:
Validar el flujo inicial de captura de patentes con el docente antes de incorporar 
las integraciones con servicios externos (PDI/SAG).
